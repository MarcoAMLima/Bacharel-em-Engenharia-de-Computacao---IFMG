function calcular() {
  var n1 = parseFloat($("#precocusto").val();
  window.alert(n1);
  var n2 = parseFloat($("#mask-lucro").val();
  var precof = n1 + ((n1*(n2/100));
  $("#precofinal").val(precof);
}