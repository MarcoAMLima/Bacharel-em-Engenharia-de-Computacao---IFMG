/**
 * Web Service em Java
 *
 * @author Filipe Soares Fernandes, RA:0022921
 * @author Marco Aurélio Monteiro Lima, RA:0022933
 * @author Pâmela Evelyn Carvalho, RA:0015669
 */

package ws;

import java.util.Set;
import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(ws.PessoaWS.class);
    }
    
}
