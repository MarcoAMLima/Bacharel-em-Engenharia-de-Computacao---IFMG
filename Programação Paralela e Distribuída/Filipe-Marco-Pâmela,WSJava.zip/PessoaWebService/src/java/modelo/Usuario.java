/**
 * Web Service em Java
 *
 * @author Filipe Soares Fernandes, RA:0022921
 * @author Marco Aurélio Monteiro Lima, RA:0022933
 * @author Pâmela Evelyn Carvalho, RA:0015669
 */

package modelo;

public class Usuario {
    
    private String login;
    private String senha;
    private String email;
    private String perfil;
    private String cpf;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }
}
